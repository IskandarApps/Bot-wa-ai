# Deploy ke cPanel

## 1. Persiapan
- Upload seluruh isi folder proyek ke public_html atau subdomain.
- Pastikan Node.js tersedia di hosting Anda. Jika cPanel tidak mendukung Node.js langsung, gunakan layanan lain atau jalankan melalui terminal khusus.
- Jalankan instalasi dependensi:
  - npm install

## 2. Variabel lingkungan
Tambahkan variabel berikut di panel hosting atau file .env (jika hosting mendukung):

- PORT=3000
- BOT_NUMBER=628xxxxxxxxxx
- API_KEY=token-anda
- GEMINI_ENABLED=true
- GEMINI_API_KEY=AIza...
- GEMINI_MODEL=gemini-1.5-flash
- GEMINI_FALLBACK_MESSAGE=Terima kasih, tim kami akan membantu.

## 3. Jalankan aplikasi
- npm start

## 4. Catatan penting
- Untuk WhatsApp, biasanya Anda membutuhkan akun resmi dan QR/pairing code untuk menghubungkan bot.
- Untuk cPanel, fitur AI Gemini hanya bekerja jika server dapat terhubung ke internet dan API Google Gemini dapat diakses.
- Simpan token API dan nomor bot dengan aman.
