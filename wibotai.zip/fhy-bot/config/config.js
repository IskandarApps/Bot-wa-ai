module.exports = {
    PORT: process.env.PORT || 3000,
    BOT_NUMBER: process.env.BOT_NUMBER || '628965777777',
    API_KEY: process.env.API_KEY || 'your-api-key-here',
    WEBHOOK_TIMEOUT: 2000,
    WEBHOOK_SANITATION: false,
    SOCKET_TIMEOUT: 3000,
    SOCKET_ATTEMPTS: 5,
    SOCKET_PAIRING: false,
    CORS_ORIGIN: ['http://localhost:3000', 'http://test.local'],
    CORS_CREDENTIALS: false,
    SELF_MODE_GLOBAL: true,
    SELF_MODE_PLUGIN: true,
    GROUP_GREETING: false,
    MESSAGE_LOG_RAW: false,

    GEMINI_ENABLED: process.env.GEMINI_ENABLED === 'true',
    GEMINI_API_KEY: process.env.GEMINI_API_KEY || '',
    GEMINI_MODEL: process.env.GEMINI_MODEL || 'gemini-1.5-flash',
    GEMINI_FALLBACK_MESSAGE: process.env.GEMINI_FALLBACK_MESSAGE || 'Halo, saya Dwi Ai. Saya siap membantu Anda terkait layanan konstruksi, servis bangunan, pipa air, dan listrik. Silakan jelaskan kebutuhan Anda.',
    GEMINI_SYSTEM_PROMPT: process.env.GEMINI_SYSTEM_PROMPT || 'Anda adalah Dwi Ai, customer service AI untuk bisnis jasa konstruksi bangunan, servis, pipa air, dan listrik. Selalu jawab sopan, singkat, profesional, dan berorientasi membantu pelanggan seperti asisten bisnis di WhatsApp.',
    GEMINI_BUSINESS_CONTEXT: process.env.GEMINI_BUSINESS_CONTEXT || 'Bisnis ini menyediakan jasa konstruksi bangunan, renovasi, perbaikan rumah, pemasangan dan perbaikan pipa air, serta instalasi listrik. Fokus utamanya adalah membantu pelanggan mencari solusi cepat, aman, dan profesional untuk kebutuhan bangunan dan perawatan rumah.'
};